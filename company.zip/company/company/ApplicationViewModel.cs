﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;
using company.Models;

namespace company
{
    public class ApplicationViewModel: INotifyPropertyChanged
    {
        private Employer selectedEmpoyer;
        public ObservableCollection<Employer> Employers { get; set; }
        public Employer SelectedEmployer
        {
            get { return selectedEmpoyer; }
            set
            {
                this.selectedEmpoyer = value;
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(@"Selected Employer"));
            }
        }
        
        
        private Departament selectedDepartament;
        public ObservableCollection<Departament> Departaments { get; set; }
        public Departament SelectedDepartament
        {
            get { return selectedDepartament; }
            set
            {
                this.selectedDepartament = value;
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(@"Selected Departament"));
            }
        }

        public ApplicationViewModel()
        {
            Employers = new ObservableCollection<Employer>
            {
                new Employer{ Name=@"Bob", Surname=@"Johnson", Age = 25, Salary = 56000},
                new Employer{Name=@"Steeve", Surname=@"Ackels", Age = 30, Salary = 44000},
                new Employer{Name =@"Sandy", Surname= @"Dean", Age = 28, Salary = 32000}
            };
            Departaments = new ObservableCollection<Departament>
            {
                new Departament{Name=@"Managers"},
                new Departament{Name=@"Sailse"}
            };
        }



        public event PropertyChangedEventHandler PropertyChanged;
    }
}
