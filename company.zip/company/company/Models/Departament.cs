﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace company.Models
{
    public class Departament : INotifyPropertyChanged
    {
        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                this.name = value;
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(@"Departament Name"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
