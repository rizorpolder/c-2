﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace company.Models
{
    public class Employer : INotifyPropertyChanged
    {
        private string name;
        private string surname;
        private int age;
        private int salary;

        public string Name
        {
            get { return name; }
            set
            {
                this.name = value;
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(@"Name"));
            }
        }
        public string Surname
        {
            get { return surname; }
            set
            {
                this.surname = value;
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(@"Surname"));
            }
        }
        public int Age
        {
            get { return age; }
            set
            {
                this.age = value;
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(@"Age"));
            }
        }
        public int Salary
        {
            get { return salary; }
            set
            {
                this.salary = value;
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(@"Salary"));
            }
        }
        
        public event PropertyChangedEventHandler PropertyChanged;
    }
}